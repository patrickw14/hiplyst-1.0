function AbstractInfo() {
}

AbstractInfo.prototype.getContents = function() {
    // Возвращает весь контент в HTML
    return "";
};