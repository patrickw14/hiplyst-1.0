# -*- encoding: utf-8 -*-
from django.contrib import admin
from models import *

admin.site.register(Pages)
admin.site.register(Albums)
admin.site.register(Tracks)
admin.site.register(Similar)
